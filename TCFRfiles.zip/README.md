# 📄 Text Classifier — scikit-learn

A complete text classification project using the **20 Newsgroups** dataset, comparing four ML models.

## Models Compared
| Model | Notes |
|---|---|
| Naive Bayes | Fast baseline, great for text |
| Logistic Regression | Strong linear classifier with TF-IDF bigrams |
| Linear SVM | Often best performer on text |
| Random Forest | Ensemble, slower but robust |

## Quick Start

```bash
pip install -r requirements.txt
python text_classifier.py
```

## Project Structure
```
text_classifier/
├── text_classifier.py   # Main script: load, train, evaluate, predict
├── requirements.txt
└── README.md
```

## How It Works
1. **Data**: 20 Newsgroups (5 categories, headers/footers removed)
2. **Features**: TF-IDF with unigrams + bigrams, sublinear TF scaling
3. **Training**: All four pipelines trained on the train split
4. **Evaluation**: Accuracy, classification report (precision/recall/F1)
5. **Inference**: Predict any new text using the best model

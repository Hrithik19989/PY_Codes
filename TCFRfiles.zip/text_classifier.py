"""
Text Classifier using sklearn
Uses synthetic data (no internet required).
Compares: Naive Bayes, Logistic Regression, SVM, Random Forest
"""

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, accuracy_score
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')


# ─── Synthetic Dataset ────────────────────────────────────────────────────────

CATEGORIES = {
    "science/space":    ["rocket nasa astronaut orbit satellite galaxy telescope launch spacecraft shuttle",
                         "mars moon planet jupiter solar system comet asteroid mission crew"],
    "science/medicine": ["patient doctor hospital surgery medicine drug treatment diagnosis disease immune",
                         "vaccine virus bacteria clinical trial therapy prescription health symptom remedy"],
    "sports/hockey":    ["hockey goal puck goalkeeper penalty shoot skate rink ice team score",
                         "player league season championship referee stick pass offside assist period"],
    "politics/guns":    ["gun rifle firearm amendment rights legislation ban policy weapon control",
                         "congress senate bill law enforcement shooting regulation permit carry background"],
    "tech/graphics":    ["pixel render shader GPU 3D OpenGL texture mesh polygon raytracing graphics",
                         "image resolution display monitor canvas bitmap vector algorithm viewport frame"],
}

def make_dataset(n_per_class=300, seed=42):
    rng = np.random.default_rng(seed)
    texts, labels = [], []
    label_names = list(CATEGORIES.keys())

    for idx, (cat, word_pools) in enumerate(CATEGORIES.items()):
        pool = " ".join(word_pools).split()
        for _ in range(n_per_class):
            size = rng.integers(15, 60)
            sentence = " ".join(rng.choice(pool, size=size, replace=True))
            texts.append(sentence)
            labels.append(idx)

    return texts, labels, label_names


# ─── Pipelines ────────────────────────────────────────────────────────────────

def build_pipelines():
    return {
        "Naive Bayes": Pipeline([
            ('tfidf', TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)),
            ('clf',   MultinomialNB()),
        ]),
        "Logistic Regression": Pipeline([
            ('tfidf', TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)),
            ('clf',   LogisticRegression(C=5, max_iter=500)),
        ]),
        "Linear SVM": Pipeline([
            ('tfidf', TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)),
            ('clf',   LinearSVC(C=1.0, max_iter=2000)),
        ]),
        "Random Forest": Pipeline([
            ('tfidf', TfidfVectorizer(max_features=5000)),
            ('clf',   RandomForestClassifier(n_estimators=100, n_jobs=-1, random_state=42)),
        ]),
    }


# ─── Train & Evaluate ─────────────────────────────────────────────────────────

def train_and_evaluate(pipelines, X_train, X_test, y_train, y_test, label_names):
    results = {}
    for name, pipe in pipelines.items():
        pipe.fit(X_train, y_train)
        preds = pipe.predict(X_test)
        acc   = accuracy_score(y_test, preds)
        results[name] = {"pipeline": pipe, "accuracy": acc, "preds": preds}
        print(f"  {name:<22} → Accuracy: {acc:.4f}")
    print()

    best_name = max(results, key=lambda k: results[k]["accuracy"])
    best      = results[best_name]
    print("=" * 60)
    print(f"🏆  Best Model : {best_name}  ({best['accuracy']:.4f})")
    print("=" * 60)
    print(classification_report(y_test, best["preds"], target_names=label_names))
    return results, best_name


# ─── Predict New Texts ────────────────────────────────────────────────────────

def predict_samples(pipeline, label_names):
    samples = [
        "The spacecraft launched into orbit carrying a crew of six astronauts.",
        "Doctors prescribed antibiotics after diagnosing a bacterial infection.",
        "The team scored two goals in the final period of the hockey game.",
        "The senate voted on new legislation to regulate firearm purchases.",
        "GPU shaders render complex 3D polygon meshes in real time.",
    ]
    preds = pipeline.predict(samples)
    has_proba = hasattr(pipeline.named_steps['clf'], 'predict_proba')
    proba = pipeline.predict_proba(samples) if has_proba else None

    print("\n🔍 Sample Predictions:")
    print("-" * 60)
    for i, text in enumerate(samples):
        label = label_names[preds[i]]
        conf  = f"{proba[i][preds[i]]:.1%}" if proba is not None else "—"
        print(f"  Text    : {text}")
        print(f"  → Class : {label}   Confidence: {conf}\n")


# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("📦 Generating synthetic dataset...")
    texts, labels, label_names = make_dataset(n_per_class=300)
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=0.2, random_state=42, stratify=labels)
    print(f"   Train: {len(X_train)}  |  Test: {len(X_test)}")
    print(f"   Classes: {label_names}\n")

    print("🔧 Training models...\n")
    pipelines = build_pipelines()
    results, best_name = train_and_evaluate(
        pipelines, X_train, X_test, y_train, y_test, label_names)

    best_pipeline = results[best_name]["pipeline"]
    predict_samples(best_pipeline, label_names)
